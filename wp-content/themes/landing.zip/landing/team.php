<div class="team-block">
	<div class="title-block">
		<h4>Who we are</h4>
		<h3>MEET OUR TEAM</h3>
		<hr class="slider-line">
		<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
	</div>
	<div class="info-team-block">
		<div class="photo-block">
			<div>
				<img class="team-image w-100" src="<?php echo get_template_directory_uri(); ?>/assets/images/team1.png" alt="First slide">
          <ul>
            <li>
              <a href="#" class="facebook">
                </a>
            </li>
            <li>
              <a href="#" class="twitter">
                </a>
            </li>
            <li>
              <a href="#" class="pinterest">
                </a>
              </li>
            <li>
              <a href="#" class="instagram">
              </a>
            </li>
				</ul>
			</div>
			<h5>MATTHEW DIX</h5>
			<p>Graphoc Design</p>
		</div>
		<div class="photo-block">
			<div>
				<img class="team-image w-100" src="<?php echo get_template_directory_uri(); ?>/assets/images/team2.png" alt="Team second">
				<ul>
					<li>
						<a href="#" class="facebook"></a>
					</li>
					<li>
					  <a href="#" class="twitter"></a>
					</li>
					<li>
					  <a href="#" class="pinterest"></a>
					</li>
					<li>
					  <a href="#" class="instagram"></a>
					</li>
				</ul>
			</div>
			<h5>CRISTOPHER CAMPBELL</h5>
			<p>Branding/UX design</p>
		</div>
		<div class="photo-block">
			<div>
				<img class="team-image w-100" src="<?php echo get_template_directory_uri(); ?>/assets/images/team1.png" alt="Team third">
				<ul>
					<li>
            <a href="#" class="facebook"></a>
					</li>
					<li>
            <a href="#" class="twitter"></a>
					</li>
					<li>
            <a href="#" class="pinterest"></a>
					</li>
					<li>
            <a href="#" class="instagram"></a>
					</li>
				</ul>
      		</div>
			<h5>MICHAEL FERTIG</h5>
			<p>Developer</p>
		</div>

	</div>
</div>