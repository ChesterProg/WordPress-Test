<?php
/*
Template Name: Main
*/
?>

<?php
get_header();
?>
<?php
get_template_part('heroblock');
?>
<?php
get_template_part('service-block');
?>
<?php
get_template_part('team');
?>
<?php
get_template_part('latestblock');
?>
<?php
get_footer();
?>
